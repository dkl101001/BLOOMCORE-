# Integration (Drop into BLOOMCORE)

This kit is intended to be copied into your BLOOMCORE repository.

## Files

- `docs/GREEK_SYMBOL_LEGEND.md`
- `docs/TOPOLOGY.md`
- `docs/README_CROSSLINK_SNIPPETS.md`
- `scripts/gen_symbol_index.py`
- `.pre-commit-config.yaml`

## Steps

1) Copy the `docs/` and `scripts/` contents into BLOOMCORE.
2) Add the README snippet from `docs/README_CROSSLINK_SNIPPETS.md` to your BLOOMCORE `README.md`.
3) Install pre-commit (one-time):

```bash
pip install pre-commit
pre-commit install
```

4) Generate the index (first run):

```bash
python scripts/gen_symbol_index.py
```

The pre-commit hook will keep `docs/SYMBOL_INDEX.md` and `docs/SYMBOL_INDEX.json` up to date.
