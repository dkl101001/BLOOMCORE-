#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List

SYMBOLS = ["Φ", "Δ", "χ", "Σ", "Ω", "τ", "μ", "ΔV"]

RE = re.compile(
    r"""^\s*(?:
            \#\s*(?P<sym1>Φ|Δ|χ|Σ|Ω|τ|μ|ΔV)\s*[:\-]\s*(?P<txt1>.+?)\s*$
          |
            /\*\s*(?P<sym2>Φ|Δ|χ|Σ|Ω|τ|μ|ΔV)\s*[:\-]\s*(?P<txt2>.+?)\s*\*/\s*$
        )""",
    re.VERBOSE,
)

DEFAULT_EXCLUDE_DIRS = {
    ".git",
    ".venv",
    "venv",
    "ENV",
    "env",
    "__pycache__",
    "build",
    "dist",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
}

DEFAULT_EXTS = {".py", ".js", ".ts", ".tsx", ".go", ".rs", ".java", ".c", ".cc", ".cpp", ".h", ".hpp", ".md"}


@dataclass(frozen=True)
class SymbolHit:
    symbol: str
    text: str
    relpath: str
    line: int
    context: str


def iter_files(root: Path, exts: set[str], exclude_dirs: set[str]) -> Iterable[Path]:
    for p in root.rglob("*"):
        if not p.is_file():
            continue
        parts = set(p.parts)
        if parts & exclude_dirs:
            continue
        if p.suffix.lower() in exts:
            yield p


def extract_hits(path: Path, root: Path) -> List[SymbolHit]:
    hits: List[SymbolHit] = []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return hits

    rel = str(path.relative_to(root))
    for i, line in enumerate(lines, start=1):
        m = RE.match(line)
        if not m:
            continue
        sym = m.group("sym1") or m.group("sym2")
        txt = (m.group("txt1") or m.group("txt2") or "").strip()
        if sym and txt:
            hits.append(SymbolHit(symbol=sym, text=txt, relpath=rel, line=i, context=line.strip()))
    return hits


def group_hits(hits: List[SymbolHit]) -> Dict[str, List[SymbolHit]]:
    out: Dict[str, List[SymbolHit]] = {s: [] for s in SYMBOLS}
    for h in hits:
        out.setdefault(h.symbol, []).append(h)
    for sym in out:
        out[sym].sort(key=lambda x: (x.relpath, x.line))
    return out


def md_header() -> str:
    return """# Symbol Index (Auto-Generated)

This file is generated from symbol-tagged comments in the codebase.

**Format recognized**
- `# Φ: ...`
- `# Δ: ...`
- `# χ: ...`
- `# Σ: ...`
- `# Ω: ...`
- `# τ: ...`
- `# μ: ...`
- `# ΔV: ...`

Do not hand-edit this file. Edit the source comments and re-run the generator.

"""


def escape_md(s: str) -> str:
    return s.replace("|", "\\|").replace("\n", " ").strip()


def anchor(sym: str) -> str:
    return (
        sym.lower()
        .replace("Δ", "δ")
        .replace("Φ", "φ")
        .replace("Σ", "σ")
        .replace("Ω", "ω")
        .replace("Δv", "δv")
    )


def render_md(groups: Dict[str, List[SymbolHit]]) -> str:
    lines: List[str] = [md_header()]

    lines.append("## Index")
    for sym in SYMBOLS:
        lines.append(f"- [{sym}](#{anchor(sym)})")
    lines.append("")

    for sym in SYMBOLS:
        lines.append(f"## {sym}")
        hits = groups.get(sym, [])
        if not hits:
            lines.append("_No entries found._\n")
            continue
        lines.append("| Location | Note |")
        lines.append("|---|---|")
        for h in hits:
            loc = f"`{h.relpath}:{h.line}`"
            lines.append(f"| {loc} | {escape_md(h.text)} |")
        lines.append("")

    return "\n".join(lines)


def render_json(groups: Dict[str, List[SymbolHit]]) -> dict:
    return {
        "generated_by": "scripts/gen_symbol_index.py",
        "symbols": [
            {
                "symbol": sym,
                "items": [
                    {"path": h.relpath, "line": h.line, "text": h.text, "context": h.context}
                    for h in groups.get(sym, [])
                ],
            }
            for sym in SYMBOLS
        ],
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".", help="Repo root")
    ap.add_argument("--out-md", default="docs/SYMBOL_INDEX.md", help="Markdown output path")
    ap.add_argument("--out-json", default="docs/SYMBOL_INDEX.json", help="JSON output path")
    ap.add_argument("--exts", default=",".join(sorted(DEFAULT_EXTS)), help="Comma-separated extensions")
    ap.add_argument(
        "--exclude-dirs",
        default=",".join(sorted(DEFAULT_EXCLUDE_DIRS)),
        help="Comma-separated directory names to skip",
    )
    args = ap.parse_args()

    root = Path(args.root).resolve()
    exts = {e.strip() for e in args.exts.split(",") if e.strip()}
    exclude_dirs = {d.strip() for d in args.exclude_dirs.split(",") if d.strip()}

    all_hits: List[SymbolHit] = []
    for f in iter_files(root, exts, exclude_dirs):
        all_hits.extend(extract_hits(f, root))

    groups = group_hits(all_hits)

    out_md = root / args.out_md
    out_json = root / args.out_json
    out_md.parent.mkdir(parents=True, exist_ok=True)
    out_json.parent.mkdir(parents=True, exist_ok=True)

    out_md.write_text(render_md(groups), encoding="utf-8")
    out_json.write_text(json.dumps(render_json(groups), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    total = sum(len(groups.get(s, [])) for s in groups)
    print(f"Wrote {args.out_md} and {args.out_json} (entries={total})")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
