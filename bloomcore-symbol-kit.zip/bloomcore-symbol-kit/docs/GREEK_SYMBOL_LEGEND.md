# Greek Symbol Legend  
## BLOOMCORE · Da Vinci Market Node  
### Myth as Compression · Math as Enforcement

This system uses Greek and physics symbols **deliberately**.  
They are not aesthetic, mystical, or decorative.

They are **semantic compression** for recurring structural roles that appear in:
- physics,
- control systems,
- markets,
- and complex decision engines.

Each symbol maps to a **real module**, **data flow**, or **governance function**.

This is not myth layered on software.  
It is software acknowledging patterns older than software.

---

## Φ — The Field (Market State)

**Φ** represents the **live market field**: the total observable state before interpretation.

**In physics:** a field of forces or potentials  
**In BLOOMCORE / Da Vinci Node:** normalized market reality

**Concrete mappings**
- Market adapters: Index · Rates · Commodities · Crypto · Earnings · Vol
- Snapshot + streaming ingestion
- Time-aligned, replayable state frames

**Why Φ matters**  
Markets do not act.  
They **propagate**.

Φ is the substrate on which everything else operates.

---

## Δ — Transformation (Change Extraction)

**Δ** represents **structured change** extracted from Φ.

**In physics:** delta, change between states  
**In the system:** feature extraction and regime inference

**Concrete mappings**
- Breadth metrics
- Volatility structure
- Tail detection
- Cross-asset correlation
- Session-aware transforms (OPEN pulse, intraday phases)

**Why Δ matters**  
Raw data is noise.  
Δ converts motion into signal without prescribing action.

---

## χ — Choice (Decision Under Uncertainty)

**χ** represents **decision-making under uncertainty**.

**In statistics/physics:** a random variable  
**In the system:** strategy logic producing *intent*, not execution

**Concrete mappings**
- Strategy plugins (e.g., ORB / VWAP / breadth / tails)
- Parameterized logic
- Non-deterministic mutation (seeded, replayable)

**Outputs**
- Typed **OrderIntents**
- Probabilistic hypotheses with confidence weights

**Why χ matters**  
Markets are probabilistic.  
χ acknowledges uncertainty instead of pretending it does not exist.

---

## Σ — Governance (Constraint & Risk)

**Σ** represents **aggregation and enforcement of limits**.

**In mathematics:** summation, boundary conditions  
**In the system:** risk and safety governance

**Concrete mappings**
- Sentinel (Lite / Full)
- Exposure caps
- Order-rate limits
- Volatility & liquidity tripwires
- Symbol, portfolio, and global kill switches

**Why Σ matters**  
Prediction without constraint is gambling.  
Σ ensures the system survives contact with reality.

---

## Ω — Execution (Finality)

**Ω** represents **collapse into action**.

**In physics:** limit, terminal state  
**In the system:** order execution and lifecycle

**Concrete mappings**
- OMS / EMS
- Broker adapters
- Order acknowledgements, fills, cancels, rejects

**Why Ω matters**  
All probabilities collapse at Ω.  
Everything before it is theory.

---

## τ — Time (Recursion & Re-evaluation)

**τ** represents **temporal structure**.

**In physics:** characteristic time constant  
**In the system:** scheduled and event-driven re-evaluation

**Concrete mappings**
- Dreamloop
- Checkpoints (e.g., 10:15 · 11:45 · 13:30)
- Drift-triggered reassessment

**Why τ matters**  
Markets evolve.  
τ prevents stale conviction from masquerading as confidence.

---

## μ — Integrity (Consistency & Trust)

**μ** represents **internal consistency**.

**In statistics:** mean, central tendency  
**In the system:** coherence across state, receipts, and history

**Concrete mappings**
- Mirrorseed
- Contradiction detection
- Integrity states: `clear · warn · break`

**Why μ matters**  
If the system contradicts itself, it cannot be trusted—regardless of PnL.

---

## ΔV — Impulse (Deliberate Intervention)

**ΔV** represents **intentional change applied to the system**.

**In orbital mechanics:** velocity change  
**In the system:** explicit intervention or mode shift

**Examples**
- Switching paper → live
- Tightening risk under elevated tails
- Scaling exposure after regime confirmation

**Why ΔV matters**  
Action is expensive.  
ΔV should be intentional, bounded, and recorded.

---

## Canonical Flow

```
Φ → Δ → χ → Σ → Ω
        ↑     ↓
        τ     μ
```

- **Φ** provides reality  
- **Δ** extracts structure  
- **χ** proposes intent  
- **Σ** enforces survival  
- **Ω** commits action  
- **τ** forces re-evaluation  
- **μ** enforces truth

---

## Final Principle

Myth is how humans name structure.  
Math is how we enforce it.

BLOOMCORE uses both—  
not for theater,  
but because **complex systems demand compression before precision**.
