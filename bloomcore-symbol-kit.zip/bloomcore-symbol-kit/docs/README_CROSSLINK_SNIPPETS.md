# Cross-link Snippets (Drop-in)

Use these snippets to cross-link the legend into existing BLOOMCORE docs without duplicating content.

---

## README.md snippet

```md
## Symbolic Architecture (Canonical)

BLOOMCORE uses Greek and physics symbols as **semantic compression** for system roles.
These symbols are not metaphorical—they map directly to concrete modules and data flows.

→ See: [Greek Symbol Legend](docs/GREEK_SYMBOL_LEGEND.md)

Canonical execution flow:

Φ → Δ → χ → Σ → Ω  
with τ enforcing time and μ enforcing integrity.
```

---

## Architecture doc note

```md
> **Design Note — Symbol Mapping**
>
> BLOOMCORE components are referenced using the canonical symbol legend:
> - Φ (Field / State)
> - Δ (Transformation)
> - χ (Choice / Strategy)
> - Σ (Governance / Risk)
> - Ω (Execution)
> - τ (Time / Recursion)
> - μ (Integrity / Consistency)
> - ΔV (Deliberate Intervention)
>
> Defined in `docs/GREEK_SYMBOL_LEGEND.md` and treated as a public system contract.
```
