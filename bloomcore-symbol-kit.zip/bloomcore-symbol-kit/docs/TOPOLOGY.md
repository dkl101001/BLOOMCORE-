# BLOOMCORE Topology — Symbolic Execution Flow

This page defines the canonical topology using the Greek/physics symbol legend.

- Solid arrows: primary data / decision flow
- Dotted arrows: enforcement, re-evaluation, or validation paths

---

## Diagram (GitHub-renderable)

```mermaid
flowchart LR
    Φ["Φ<br/>Field<br/>(Market State)"]
    Δ["Δ<br/>Transform<br/>(Features & Regimes)"]
    χ["χ<br/>Choice<br/>(Strategy / Intent)"]
    Σ["Σ<br/>Governance<br/>(Risk & Constraints)"]
    Ω["Ω<br/>Execution<br/>(Orders & Fills)"]

    τ["τ<br/>Time<br/>(Checkpoints / Re-eval)"]
    μ["μ<br/>Integrity<br/>(Mirrorseed)"]

    Φ --> Δ
    Δ --> χ
    χ --> Σ
    Σ --> Ω

    τ -.-> Δ
    τ -.-> χ
    τ -.-> Σ

    μ -.-> Φ
    μ -.-> Δ
    μ -.-> χ
    μ -.-> Σ
    μ -.-> Ω
```

---

## ASCII fallback

```text
          τ (Time)
           ↘   ↘
Φ → Δ → χ → Σ → Ω
↑   ↑   ↑   ↑   ↑
└────── μ (Integrity) ──────┘
```

---

## Quick legend

- **Φ** = Field / Market State
- **Δ** = Transformation (features, regimes)
- **χ** = Choice (strategy intent)
- **Σ** = Governance (risk, limits)
- **Ω** = Execution (orders, fills)
- **τ** = Time (checkpoints, re-evaluation)
- **μ** = Integrity (contradiction detection)
- **ΔV** = Deliberate intervention (mode shift)
