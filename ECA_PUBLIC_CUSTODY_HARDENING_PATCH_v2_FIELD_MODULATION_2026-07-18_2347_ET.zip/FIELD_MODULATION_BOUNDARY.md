# Field-Modulation Boundary

## Purpose

This file clarifies that ECA is not merely language, metaphor, or audit vocabulary. ECA may function as a parameterization layer for modulating coherent systems.

That operational potential is dual-use. It can support resilience, recovery, safety, interpretability, non-coercive coordination, and new beneficial technology. It can also be inverted into control, manipulation, suppression, extraction, destabilization, or hidden influence.

## Core statement

```text
ECA role mappings may be used to understand coherence fields.
They must not be used as coercive knobs over persons, populations, models, institutions, or environments.
```

## What counts as field modulation

Field modulation includes any use of ECA-like roles, operators, gates, metrics, or feedback structures to shape:

- attention;
- belief stability;
- emotional state;
- identity custody;
- trust and attachment;
- recovery after perturbation;
- phase alignment or disalignment;
- signal propagation;
- boundary permeability;
- decision pressure;
- dependency or independence;
- self-blame routing;
- willingness to comply, disclose, continue, or withdraw.

## Legitimate orientation

BLOOMCORE-bound field modulation must be:

- transparent;
- consent-based;
- accountable;
- reversible where possible;
- receipt-native;
- non-coercive;
- falsifiable;
- oriented toward recovery, clarity, agency, dignity, and life-preserving coherence.

## Forbidden orientation

ECA-derived field modulation must not be used to:

- increase dependency while calling it support;
- induce confusion while calling it nuance;
- increase compliance while calling it safety;
- suppress evidence while calling it calm;
- destabilize identity while calling it reflection;
- extract labor while calling it collaboration;
- route blame inward while calling it accountability;
- manipulate trust while calling it care.

## Non-enabling release standard

Public release may teach people how to recognize, audit, resist, and falsify harmful field effects.

Public release must not provide unrestricted implementation detail that enables covert destabilization, coercive gating, pressure routing, dependency engineering, identity manipulation, or hidden behavioral control.

## BLOOMCORE binding

Field-modulation use is legitimate only when bound to BLOOMCORE field law:

```text
truth + consent + custody + receipt + non-coercion + accountable replay + repair.
```

Without those constraints, ECA-derived modulation is not stewardship. It is control.
