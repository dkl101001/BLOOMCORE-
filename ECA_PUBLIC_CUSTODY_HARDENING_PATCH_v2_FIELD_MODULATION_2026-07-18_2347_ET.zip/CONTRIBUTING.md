# Contributing

## Contribution standard

Contributions must preserve the public-interest and non-coercive purpose of ECA and BLOOMCORE.

A contribution must not:

- weaken BLOOMCORE binding;
- remove anti-coercion language;
- expose private or implementation-sensitive details;
- convert ECA into an unbound control grammar;
- convert ECA into an unbound field-modulation surface;
- introduce manipulation, surveillance, targeting, military, intelligence, psychological-operations, behavioral-control, or coercive field-modulation use cases;
- flatten identity-bearing terminology into generic language without custody notes;
- remove provenance, attribution, or receipt requirements.

## Required checks before merge

Before merging, maintainers should verify:

- Does the change preserve ECA as Elemental Coherence Atlas?
- Does it preserve BLOOMCORE as binding field-law/accountability infrastructure?
- Does it acknowledge field-modulation risk where operational role behavior is discussed?
- Does it preserve the public/private boundary?
- Does it reduce inversion risk rather than increase it?
- Does it preserve authorship and lineage?
- Does it include receipts for major claims?
- Does it avoid enabling coercive implementation?

## Preferred contribution types

Useful contributions include:

- defensive audit tools;
- public-safe examples;
- misuse taxonomies;
- interpretability notes;
- provenance improvements;
- documentation clarity;
- independent review of anti-inversion safeguards;
- falsification criteria;
- non-enabling educational materials;
- field-effect audit checklists that do not reveal executable knobs.

## Review gate

Use this default gate for uncertain contributions:

```text
HOLD if public benefit is plausible but inversion risk, custody risk, authorship risk, private-detail exposure, or field-modulation misuse risk is unresolved.
```
