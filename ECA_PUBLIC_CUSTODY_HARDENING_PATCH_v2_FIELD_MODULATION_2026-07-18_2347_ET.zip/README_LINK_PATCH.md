# README Link Patch

Add a section like this to the repository README.

## Custody, Safety, and Anti-Inversion

ECA is the Elemental Coherence Atlas. It is not valid as an unbound control grammar or unbound field-modulation surface.

This repository treats ECA as BLOOMCORE-bound: it must remain subordinate to field law, non-coercion, receipt integrity, authorship custody, role separation, public/private membranes, and accountable replay.

ECA role mappings may have operational force. They may function as knobs for coherence behavior: damping, gating, propagation, feedback fidelity, dissipation, transformation, and boundary permeability. This makes BLOOMCORE binding non-optional.

Please read:

- [`DISCLAIMER.md`](./DISCLAIMER.md)
- [`BLOOMCORE_BINDING.md`](./BLOOMCORE_BINDING.md)
- [`FIELD_MODULATION_BOUNDARY.md`](./FIELD_MODULATION_BOUNDARY.md)
- [`ANTI_INVERSION_BOUNDARY.md`](./ANTI_INVERSION_BOUNDARY.md)
- [`PUBLIC_PRIVATE_BOUNDARY.md`](./PUBLIC_PRIVATE_BOUNDARY.md)
- [`DEFENSIVE_AUDIT_GUIDE.md`](./DEFENSIVE_AUDIT_GUIDE.md)
- [`PROVENANCE_AND_CUSTODY.md`](./PROVENANCE_AND_CUSTODY.md)

Derivative use that removes BLOOMCORE binding, anti-coercion constraints, public/private custody membranes, field-modulation boundaries, or receipt requirements is not authorized by the spirit of this project.
