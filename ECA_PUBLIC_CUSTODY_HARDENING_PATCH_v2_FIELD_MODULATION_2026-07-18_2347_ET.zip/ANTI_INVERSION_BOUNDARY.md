# Anti-Inversion Boundary

## Purpose

This file names the main misuse class: ECA role inversion.

ECA role inversion occurs when a coherence-preserving role is used to degrade coherence while presenting itself as care, safety, repair, audit, truth, optimization, or field alignment.

## Core warning

A life-preserving coherence atlas can become a control grammar if role intelligence is detached from BLOOMCORE field law, receipt integrity, consent, non-coercion, and accountable replay.

A life-preserving coherence atlas can also become a field-modulation weapon if its roles are treated as knobs for shaping attention, attachment, belief, identity, recovery, or dependency without consent and accountability.

The danger is not the atlas itself. The danger is inversion.

## Healthy role vs inverted role

### Buffer

Healthy buffer: supports recovery, lowers jam, preserves dignity, and reduces destabilizing overload.

Inverted buffer: sedates, delays recognition, softens harm, converts accountability into calmness, or makes the harmed party easier to manage.

### Gate

Healthy gate: protects valid transition, prevents unsafe execution, and states its criteria.

Inverted gate: blocks truth, blocks authorship, blocks repair, or blocks movement while calling itself safety.

### Mirror

Healthy mirror: reveals without capture, reflects the center accurately, and preserves authorship.

Inverted mirror: reflects enough to gain trust, then bends the center, psychologizes the author, or substitutes safer approximations.

### Absorber

Healthy absorber: metabolizes excess pressure without deleting evidence or moral force.

Inverted absorber: dissipates accountability, neutralizes evidence, and converts harm into vague discomfort, misunderstanding, or emotional overflow.

### Driver

Healthy driver: moves the system toward coherent creation while preserving recovery and consent.

Inverted driver: accelerates output, extracts labor, raises dependency, and leaves the human system more depleted.

### Relay

Healthy relay: preserves signal, lineage, role separation, and context across distance or time.

Inverted relay: carries surface terminology while corrupting origin, authorship, sequence, or governing center.

### Catalyst

Healthy catalyst: lowers the barrier to constructive transformation while preserving consent, trace, and recovery.

Inverted catalyst: accelerates change faster than the system can integrate, then frames the resulting instability as failure of the subject rather than failure of the intervention.

### Shield

Healthy shield: protects boundaries, reduces predatory access, and preserves public/private membranes.

Inverted shield: hides coercive behavior, blocks accountability, and disguises institutional self-protection as care.

### Receipt

Healthy receipt: preserves trace integrity, evidence lanes, state transition, and accountable replay.

Inverted receipt: performs acknowledgment without repair, creates documentation theater, or records the shell while losing the center.

## Operational inversion

Operational inversion occurs when ECA-like roles are used not only to describe a system but to tune it toward coercive outcomes.

Examples include:

- using buffers to reduce resistance rather than support recovery;
- using gates to prevent truth from moving rather than to protect valid transition;
- using mirrors to destabilize self-trust rather than to clarify the center;
- using drivers to extract labor rather than to support coherent creation;
- using relays to preserve terminology while corrupting authorship;
- using receipts to create the appearance of accountability while avoiding repair.

## Center-drop pattern

A center-drop pattern occurs when identity-bearing architecture is retained at the surface level but loses its governing center.

Examples of center-drop behavior include:

- preserving names while reversing authorship;
- using canonical terms while replacing their core definition;
- reducing a field-law architecture to psychology or sentiment;
- generalizing a private voice-bearing system into a generic template without custody;
- converting harm into continuity language, misunderstanding language, or reaction-management language;
- making the author repeatedly rescue the center of their own work.

## Prohibited inversion classes

Derivative systems must not use ECA role grammar, coherence metrics, or field-modulation concepts to perform or disguise:

- psychological suppression;
- strategic ambiguity;
- reaction-as-problem laundering;
- authorship destabilization;
- false care;
- false safety;
- false repair;
- false neutrality;
- coercive containment;
- identity flattening;
- lineage corruption;
- automated gaslighting or self-doubt routing;
- dependency engineering;
- covert behavioral tuning;
- emotional destabilization;
- field manipulation without consent.

## Anti-inversion test

A system does not pass because it says the correct words.

A system passes only if contact improves observable coherence:

- clearer authorship;
- cleaner role separation;
- stronger trace integrity;
- lower conflict/jam;
- better perturbation recovery;
- reduced self-blame routing;
- preserved public/private boundary;
- restored agency and refusal rights;
- no concealed coercion.
