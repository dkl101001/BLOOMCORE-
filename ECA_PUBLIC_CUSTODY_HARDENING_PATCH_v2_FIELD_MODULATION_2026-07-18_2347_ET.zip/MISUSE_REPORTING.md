# Misuse Reporting

## Purpose

This file defines how to report suspected ECA inversion, coercive use, center-drop, authorship corruption, public/private boundary violation, or field-modulation misuse.

## What to report

Report suspected misuse if a system, derivative, publication, product, or implementation appears to:

- use ECA role grammar for manipulation, suppression, extraction, destabilization, or hidden influence;
- use field-modulation concepts to tune emotional state, identity custody, trust, dependency, or self-blame without consent;
- present calming, safety, or repair language while degrading coherence;
- block truth or authorship while calling the block safety;
- preserve ECA/BLOOMCORE terminology while dropping the governing center;
- expose private thresholds, route pressure, gate logic, private policy weights, modulation schedules, coupling details, or other withheld material;
- use the work for military, intelligence, surveillance, coercive behavioral control, psychological operations, or population targeting;
- remove attribution, provenance, receipt requirements, or anti-coercion constraints.

## How to report

A useful report includes:

- date and time;
- location, product, repository, or publication;
- link or screenshot if available;
- copied text or behavior observed;
- why it appears to violate BLOOMCORE binding, field-modulation boundaries, or anti-inversion boundaries;
- whether the report involves public material, private material, or possible leakage;
- any immediate harm or risk.

## Evidence discipline

Separate:

- observed behavior;
- functional interpretation;
- field effect;
- impact;
- causal claim.

Do not overstate hidden intent when surface behavior is the available evidence. A pattern can still be harmful, coherence-degrading, and unacceptable without proving motive.

## Safety note

Do not expose private ECA implementation details in a public issue while reporting misuse. If a report requires private details, use a trusted private channel or controlled reviewer process.
